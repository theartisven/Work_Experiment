---
name: figma-rename-bem
description: "Rename Figma layers in BEM format (block__element--modifier). Use for /figma-rename-bem or requests to rename layers using BEM naming."
---

# /figma-rename-bem - Rename Layers (BEM)

Supports `preview`: show intended renames without applying.

## Scope

Use `get_selection`. If empty, use `get_page_nodes`. Never full-file without confirmation.

**Always skip:**
- `type = INSTANCE` or `COMPONENT` — check via `get_node_properties`.
- Frames where `width` ∈ `{390, 768, 1440, 1920}`.

## Format

`block__element--modifier`

- **block:** nearest named ancestor (use parent `name` via `get_node_properties` on parent).
- **element:** child role within block.
- **modifier:** variant or state suffix.
- Lowercase, hyphen-separated within each segment. No spaces, no camelCase.

## Repeated Blocks

Group siblings by stem name. If 4+: append zero-padded index `block-001`. If 2–3: append `top`, `middle`, `bottom` or `left`, `right` based on `y` or `x` position.

## Record

Read all current `name` values before writing.

## Output

One line per rename:

`old name → new name`

Prefix `[preview]` in preview mode — make no writes.

Summary: `N renamed | N skipped (component) | N flagged (ambiguous)`
