---
name: figma-rename-html
description: "Rename Figma layers using semantic HTML roles for accessibility (header, nav, button, h1, img, and so on). Use for /figma-rename-html or requests to rename layers with HTML semantics."
---

# /figma-rename-html - Rename Layers (Semantic HTML)

Alias for `figma-rename-semantic`. Load and follow that skill.
