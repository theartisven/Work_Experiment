1. **Project Initialization**

   * Create a project using the filename format `YYYY_Company_Country`.
   * Download the starter files from GitHub and unzip them.
   * Run the initialization file.
   * Connect MCP servers and AI models.

2. **Asset Import**

   * Import project assets into the appropriate folders, including text, PDFs, images, and other media types.

3. **Content Conversion & Distillation**

   * Convert non-text files, such as PDF brand guidelines, into structured text using a private MarkItDown workflow.
   * Distill client-provided information, such as user personas, into standardized templates.
   * If no user persona is provided, use AI to generate an initial persona based on the available company information

4. **Design System Setup**

   * Required Figma libraries should have been specified in the initialization file.
   * If no existing libraries are available, use the appropriate skill to create design tokens from primitive to semantic levels or use template figma file.
   * Use AI to generate basic reusable components as needed.

5. **Ideation**

   * Use AI to generate design concepts and explore different design directions.
   * Generate initial wireframes or template-based layouts using AI.

6. **Mockups**

   * Use AI-assisted design skills to refine the visual design.
   * Replace placeholder content with realistic copy, imagery, and other relevant content.

7. **Testing & Refinement**

   * Use the defined user persona or other relevant personas to evaluate and critique the design.
   * Incorporate AI-generated feedback and user comments to identify issues and refine the design.

8. **Prototyping**

   * Use AI-assisted prototyping for simple interactions and user flows.
   * Keep complex interactions and advanced prototyping outside the AI-assisted workflow when necessary.

9. **Cleanup**

   * Use AI skills to remove unnecessary layers and elements.
   * Check spelling, naming consistency, and layer organization.
   * Rename layers according to the established naming convention.

10. **Componentization**

    * Audit screens to identify repeated UI patterns and elements.
    * Convert recurring elements into reusable components.
    * Ensure component properties, variants, and structures are properly defined.

11. **Refinement via Code**

    * Use AI to generate editable code for screens or individual design elements.
    * Use code to refine interactions that are difficult to implement directly in Figma, such as scroll animations and 3D elements.

12. **Developer Handoff**

    * When permitted, use AI to generate component documentation using Storybook JS.
